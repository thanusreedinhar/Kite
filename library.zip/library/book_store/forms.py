from django import forms
from .models import *

class Book(forms.ModelForm):
    class Meta:
        model=Book
        fields=['title','author','publisher','category','price','language','publish_year']
        