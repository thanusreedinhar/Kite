from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate,login,logout
from.forms import *
def book_store(request):
    return HttpResponse("hello world")
def home_page(request):
    return render(request,'home.html')
def register(request):
    form=Book(request.POST,request.FILES)
    if request.method=='POST':
        if form.is_valid():
            form.save()
            
    # if request.method=='POST':
    #     u_name=request.POST['name'] 
    #     u_email=request.POST['email']
    #     password=request.POST['password']
    #     Register.objects.create_user(username=u_name,email=u_email,password=password,usertype='user')
        return redirect('/')
    return render(request,'register.html',{'form':form})
def login(request):
    if request.method=='POST':
        u_name=request.POST['name'] 
        password=request.POST['password']
        user=authenticate(request,username=u_name,password=password)
        if user is not None:
            login(request,user)
            return redirect('/')
    return render(request,'login.html')